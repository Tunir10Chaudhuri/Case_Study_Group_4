package com.telstra;

public class TestTwo {
	
	public static void main(String[] args) {
		
		HelloWorld.hellofunc("John");
	}
}
